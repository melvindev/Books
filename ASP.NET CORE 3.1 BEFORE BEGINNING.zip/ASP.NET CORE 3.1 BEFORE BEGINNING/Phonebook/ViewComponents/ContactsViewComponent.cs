﻿using Microsoft.AspNetCore.Mvc;
using Phonebook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Phonebook.ViewComponents
{
    public class ContactsViewComponent:ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            List<PhoneBook> phoneBook = new List<PhoneBook>
            {
                //Add PhoneBook conatcts
                new PhoneBook
                {
                    Name = "Alex",
                    MiddleName = "M",
                    LastName = "Hernandez",
                    Address = "Los Angeles CA, USA",
                    Phone = "323-1234567"
                },
                new PhoneBook
                {
                    Name = "Xander",
                    MiddleName = "A",
                    LastName = "ceren",
                    Address = "Los Angeles CA, USA",
                    Phone = "323-00540000"
                },
            };

            //Will return default.cshtml from Shared/Components/Contacts/ and will
            // add the phoneBook model information
            return View(phoneBook);
        }

    }
}
