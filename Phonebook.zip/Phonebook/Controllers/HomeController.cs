﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Phonebook.Models;
namespace Phonebook.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            //Create a object list for each contact data and add information
            List<PhoneBook> phoneBook = new List<PhoneBook>
            {
                //Add PhoneBook conatcts
                new PhoneBook
                {
                    Name = "Melvin",
                    MiddleName = "A",
                    LastName = "Hernandez",
                    Address = "Los Angeles CA, USA",
                    Phone = "213-1234500"
                },
                new PhoneBook
                {
                    Name = "Alexander",
                    MiddleName = "M",
                    LastName = "Carrillo",
                    Address = "Los Angeles CA, USA",
                    Phone = "213-0054321"
                },
                new PhoneBook
                {
                    Name = "Jose",
                    MiddleName = "N",
                    LastName = "Garsesto",
                    Address = "Ontario CA, USA",
                    Phone = "213-0054340"
                }
            };
            //Title for the views
            ViewBag.Title = "Phonebook";

            //The View method will look for the view Index.cshtml on the Views/Home/Index.cshtml
            //And will pass the phoneBook model we have created above
            return View(phoneBook);
        }
    }
}
