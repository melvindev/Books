﻿
using Microsoft.AspNetCore.Mvc;
using RestaurantWebApp.Models;

namespace RestaurantWebApp.Controllers
{
    public class HomeController : Controller
    {
        [Route("/")]
        public IActionResult Index()
        {
            return RedirectToAction("RestaurantHomePage");
        }
        [Route("/restaurant")]
        public IActionResult RestaurantHomePage()
        {
            return View("Index");
        }
        [Route("/restaurant/{get}/{search}")]
        [HttpPost]
        public IActionResult SearchRestaurant(string get, string search)
        {
            return ViewComponent("FoodAndDrinks", new { get = get.ToLower(), search = search.ToLower() });
        }
        [Route("/restaurant/add/food")]
        [HttpPost]
        public IActionResult AddFood(Food food)
        {
            Restaurant.Food.Add(food);
            return Content($"Food added to list.");
        }
        [Route("/restaurant/add/drink")]
        [HttpPost]
        public IActionResult AddDrink(Drinks drinks)
        {
            Restaurant.Drinks.Add(drinks);
            return Content($"Drink added to list.");
        }
    }
}

