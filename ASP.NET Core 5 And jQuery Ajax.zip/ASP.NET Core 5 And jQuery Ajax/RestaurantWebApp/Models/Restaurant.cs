﻿
using System.Collections.Generic;
namespace RestaurantWebApp.Models
{
    public class Food
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }
    public class Drinks
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }
    public class Restaurant
    {
        public static List<Food> Food { get; set; } = new List<Food>();
        public static List<Drinks> Drinks { get; set; } = new List<Drinks>();
    }
}













