﻿

/*
 * Ajax Method:
 Search item on Restaurant.Food or on the Restaurant.Drinks properties collection on the server.
 See the public IActionResult SearchRestaurant(string get, string search){....} on the HomeController.cs
 and see these properties on Models folder in the Restaurant class.
 */
function restaurant(get, search) {
    $.post("restaurant/" + get + "/" + search, (data) => {
        $("#restaurantcontainer").html(data);
    }).fail((f) => {
        $("#restaurantcontainer").html("Something went wrong!");
    });
}

/*
 Search item on Restaurant.Food or on the Restaurant.Drinks properties collection on the server.
 See the public IActionResult SearchRestaurant(string get, string search){....} on the HomeController.cs
 */
function searchRestaurant(search) {
    var searchval = $("#searchrestaurant");
    if (searchval.val() != "") {
        restaurant(search, searchval.val());
    } else {
        $(searchval).focus();
    }
}
//****************************EXPLANATION********************************************************
//Ajax Method:
//Add items to Restaurant.Food or Restaurant.Drinks collection on the server.
//see these properties on Models folder in the Restaurant class.
//public static List <Food> Food {get; set;} = new List<Food>();
//public static List <Drinks> Drinks {get; set;} = new List<Drinks>();

//**This Method Add(addto) send the data to HomeController.cs where  the following actions get the data and add it to Restaurant.Food or Restaurant.Drinks
//public IActionResult AddFood(Food food){....} 
//and   
//public IActionResult AddDrink(Drinks drinks){....}
//**********************************************************************************************

function Add(addto) {
    if ($("#itemid").val() == "" || $("#itemname").val() == "" || $("#itemprice").val() == "") {

        $('#messagelabel').html("Fill out all fields").css({ "color": "red" });
        return;
    }
    $.ajax({
        url: "/restaurant/add/" + addto,
        method: "POST",
        data: $('#addform').serialize(),
        beforeSend: function () {
            $('#messagelabel').html("Adding...");
        },
        success: function (data) {
            $('form').trigger("reset");
            $('#messagelabel').html(data).css({ "color": "blue" });
        }
    });
}
/*
 When document is ready or refreshed we call the restaurant method with all food items that are added to Restaurant.Food on the server
 */
$(() => {
    restaurant("food", "all");
});


