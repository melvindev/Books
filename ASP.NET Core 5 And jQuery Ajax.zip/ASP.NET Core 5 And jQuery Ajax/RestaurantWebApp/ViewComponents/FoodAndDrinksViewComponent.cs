﻿using Microsoft.AspNetCore.Mvc;
using RestaurantWebApp.Models;
using System.Linq;

namespace RestaurantWebApp.ViewComponents
{
    public class FoodAndDrinksViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke(string get, string search)
        {
            //dynamic variable is resolved at runtime by specify the object type.
            dynamic data = "";
            if (get.ToLower() == "food" && !string.IsNullOrWhiteSpace(search))
            {
                if (search.ToLower() == "all")
                {
                    data = Restaurant.Food.ToList();
                }
                else
                {
                    data = Restaurant.Food.Where(x => x.Name.ToLower() == search.ToLower()).ToList();
                }
                return View(data);
            }
            //Drinks
            if (get.ToLower() == "drinks" && !string.IsNullOrWhiteSpace(search))
            {
                if (search.ToLower() == "all")
                {
                    data = Restaurant.Drinks.ToList();
                }
                else
                {
                    data = Restaurant.Drinks.Where(x => x.Name.ToLower() == search.ToLower()).ToList();
                }
                return View(data);
            }
            return View(data);
        }
    }
}
